package com.cloudwebrtc.webrtc.utils;

import android.util.Log;
import java.util.List;
import java.util.Map.Entry;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaConstraints.KeyValuePair;
import java.util.ArrayList;

public class MediaConstraintsUtils {

  static public final String TAG = "MediaConstraintsUtils";

  /**
   * Parses mandatory and optional "GUM" constraints described by a specific
   * <tt>ConstraintsMap</tt>.
   *
   * @param constraints A <tt>ConstraintsMap</tt> which represents a JavaScript object specifying
   * the constraints to be parsed into a
   * <tt>MediaConstraints</tt> instance.
   * @return A new <tt>MediaConstraints</tt> instance initialized with the mandatory and optional
   * constraint keys and values specified by
   * <tt>constraints</tt>.
   */
  // tvk re-write parseMediaConstraints method
  public static MediaConstraints parseMediaConstraints(ConstraintsMap constraints) {
      Log.d(TAG, "Checking constraints keys: " + constraints.toString());

      MediaConstraints mediaConstraints = new MediaConstraints();

      // 1. Khởi tạo danh sách tạm để hứng dữ liệu map từ parseConstraints
      ArrayList<MediaConstraints.KeyValuePair> temporaryMandatory = new ArrayList<>();
      ArrayList<MediaConstraints.KeyValuePair> temporaryOptional = new ArrayList<>();

      // 2. Parse phần mandatory gốc từ Flutter truyền xuống nếu có
      if (constraints.hasKey("mandatory") && constraints.getType("mandatory") == ObjectType.Map) {
          parseConstraints(constraints.getMap("mandatory"), temporaryMandatory);
      } else {
          Log.d(TAG, "mandatory constraints are not a map");
      }

      // 3. Parse phần optional gốc từ Flutter truyền xuống
      if (constraints.hasKey("optional") && constraints.getType("optional") == ObjectType.Array) {
          ConstraintsArray optional = constraints.getArray("optional");

          for (int i = 0, size = optional.size(); i < size; i++) {
              if (optional.getType(i) == ObjectType.Map) {
                  parseConstraints(optional.getMap(i), temporaryOptional);
              }
          }
      } else {
          Log.d(TAG, "optional constraints are not an array");
      }

      // 4. KIỂM TRA & TÁCH LỌC: Chỉ di chuyển sourceId hoặc deviceId sang mandatory
      // Tạo một danh sách tạm thời để lưu các item sẽ giữ lại ở optional nhằm tránh lỗi ConcurrentModificationException
      ArrayList<MediaConstraints.KeyValuePair> finalOptional = new ArrayList<>();

      for (MediaConstraints.KeyValuePair pair : temporaryOptional) {
          String key = pair.getKey();
          String value = pair.getValue();

          if (key.equals("sourceId") || key.equals("deviceId")) {
              Log.d(TAG, "🎯 Phát hiện định danh thiết bị âm thanh (" + key + "): " + value + ". Đang chuyển sang mandatory...");

              // WebRTC Native Android yêu cầu key định danh bắt buộc phải là "deviceId"
              // Nếu là "sourceId", ta đổi tên thành "deviceId", nếu đã là "deviceId" thì giữ nguyên.
              String targetKey = key.equals("sourceId") ? "deviceId" : key;

              temporaryMandatory.add(new MediaConstraints.KeyValuePair(targetKey, value));
          } else {
              // Các cấu hình âm thanh khác (echoCancellation, noiseSuppression, v.v.) được GIỮ NGUYÊN ở optional
              finalOptional.add(pair);
          }
      }

      // Cập nhật lại danh sách optional sau khi đã lọc bỏ ID thiết bị
      temporaryOptional = finalOptional;

      // 5. Nạp ngược dữ liệu đã xử lý vào object mediaConstraints trả về cho WebRTC Native
      mediaConstraints.mandatory.addAll(temporaryMandatory);
      mediaConstraints.optional.addAll(temporaryOptional);

      Log.d(TAG, "🚀 Cấu hình cuối cùng sau khi xử lý: mandatory=" + mediaConstraints.mandatory.toString() + ", optional=" + mediaConstraints.optional.toString());

      return mediaConstraints;
  }

  public static MediaConstraints parseMediaConstraints_old(ConstraintsMap constraints) {
      Log.d(TAG, "Checking constraints keys: " + constraints.toString());

    MediaConstraints mediaConstraints = new MediaConstraints();

    // TODO: change getUserMedia constraints format to support new syntax
    //   constraint format seems changed, and there is no mandatory any more.
    //   and has a new syntax/attrs to specify resolution
    //   should change `parseConstraints()` according
    //   see: https://www.w3.org/TR/mediacapture-streams/#idl-def-MediaTrackConstraints
      // tvk inject mandatory constraints if empty constraints detected
//      if (!constraints.hasKey("mandatory") || constraints.getMap("mandatory") == null) {
//          Log.d(TAG, "Input empty! Injecting default mandatory constraints...");
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googEchoCancellation", "false"));
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googNoiseSuppression", "false"));
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googNoiseSuppression", "false"));
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googAutoGainControl", "false"));
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("googHighpassFilter", "false"));
//          mediaConstraints.mandatory.add(new MediaConstraints.KeyValuePair("channelCount", "1"));
//      } else {
//          parseConstraints(constraints.getMap("mandatory"), mediaConstraints.mandatory);
//      }

    if (constraints.hasKey("mandatory")
        && constraints.getType("mandatory") == ObjectType.Map) {
      parseConstraints(constraints.getMap("mandatory"),
          mediaConstraints.mandatory);
    } else {
      Log.d(TAG, "mandatory constraints are not a map");
    }

    if (constraints.hasKey("optional")
        && constraints.getType("optional") == ObjectType.Array) {
      ConstraintsArray optional = constraints.getArray("optional");

      for (int i = 0, size = optional.size(); i < size; i++) {
        if (optional.getType(i) == ObjectType.Map) {
          parseConstraints(
              optional.getMap(i),
              mediaConstraints.optional);
        }
      }
    } else {
      Log.d(TAG, "optional constraints are not an array");
    }

    return mediaConstraints;
  }

  /**
   * Parses a constraint set specified in the form of a JavaScript object into a specific
   * <tt>List</tt> of <tt>MediaConstraints.KeyValuePair</tt>s.
   *
   * @param src The constraint set in the form of a JavaScript object to parse.
   * @param dst The <tt>List</tt> of <tt>MediaConstraints.KeyValuePair</tt>s into which the
   * specified <tt>src</tt> is to be parsed.
   */
  private static void parseConstraints(
      ConstraintsMap src,
      List<KeyValuePair> dst) {

    for (Entry<String, Object> entry : src.toMap().entrySet()) {
      String key = entry.getKey();
      String value = getMapStrValue(src, entry.getKey());
      dst.add(new KeyValuePair(key, value));
    }
  }

  private static String getMapStrValue(ConstraintsMap map, String key) {
    if (!map.hasKey(key)) {
      return null;
    }
    ObjectType type = map.getType(key);
    switch (type) {
      case Boolean:
        return String.valueOf(map.getBoolean(key));
      case Number:
        // Don't know how to distinguish between Int and Double from
        // ReadableType.Number. 'getInt' will fail on double value,
        // while 'getDouble' works for both.
        // return String.valueOf(map.getInt(key));
        return String.valueOf(map.getDouble(key));
      case String:
        return map.getString(key);
      default:
        return null;
    }
  }
}
